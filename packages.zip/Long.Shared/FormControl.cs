﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Long.Shared
{
    public partial class FormControl : Form
    {
        public FormControl()
        {
            InitializeComponent();
        }
    }
}
